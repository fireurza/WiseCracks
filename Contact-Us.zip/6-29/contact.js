// After form loads focus will go to User id field.  

 function firstfocus()  
 {  
  var first_name = document.registration.first_name.focus();  
  return true;  
  }  
  
// This function will validate First Nmae.  

  function allLetter()  
  {   
  var first_name = document.registration.first_name;  
  var letters = /^[A-Za-z]+$/;  
  if(first_name.value.match(letters))  
  { 
 

  // Focus goes to next field i.e. Last Name.  
  document.registration.last_name.focus();  
  return true;  
  }  
// This function will validate Last Nmae.  

  function allLetter()  
  {   
  var last_name = document.registration.last_name;  
  var letters = /^[A-Za-z]+$/;  
  if(last_name.value.match(letters))  
  { 
  
 
  // Focus goes to next field i.e. email.  
  document.registration.email.focus();  
  return true;  
  }  
    
 // This function will validate Email.  
  function ValidateEmail()  
  {  
  var email = document.registration.email;  
  var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
  if(email.value.match(mailformat))  
  {  
  document.registration.desc.focus();  
  return true;  
  }  
  else  
  {  
  alert("You have entered an invalid email address!");  
  uemail.focus();  
  return false;  
  }  
  }  
